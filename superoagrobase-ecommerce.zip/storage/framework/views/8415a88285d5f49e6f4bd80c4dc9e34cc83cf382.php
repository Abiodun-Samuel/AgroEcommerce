<?php echo e($slot); ?>

<?php /**PATH C:\Users\Admin\Desktop\web-products\superoagrobase-ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>