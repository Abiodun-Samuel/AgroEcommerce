<template>
  <footer class="footer bg-white shadow">
    <div class="container d-flex flex-column align-items-center">
      <p class="m-0 p-0">
        Copyright &#169; {{ new Date().getFullYear() }} SuperoAgrobase Ltd
      </p>
      <p class="m-0 p-0 text-muted">
        Designed & Developed By
        <a target="_blank" class="text-muted" href="https://abiodunsamuel.com/">
          <b>Abiodun Digital Hub</b>
        </a>
      </p>
    </div>
  </footer>
</template>

<script setup>
</script>

<style lang="scss" scoped>
</style>