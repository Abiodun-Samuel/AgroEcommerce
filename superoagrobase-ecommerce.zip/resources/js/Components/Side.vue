<template>
  <div class="col-lg-6 login__banner">
    <div class="pane">
      <!-- <h3 class="text-white fw-bolder">
        Best Agricultural Products and Services.
      </h3>
      <h5 class="text-white">
        Quality agricultural products and services at your fingertips 👌
      </h5> -->
      <!-- <img
        src="@/assets/images/img/auth-img.jpg"
        alt="fruits and vegetables"
        class="rounded shadow"
      /> -->
    </div>
  </div>
</template>

<style lang="css" scoped>
.pane {
  /* padding: 0.5rem; */
  /* background: rgba(255, 255, 255, 0.15); */
  /* box-shadow: var(--shadow-1); */
  /* backdrop-filter: blur(8px); */
  /* padding: 2rem 3rem; */
  /* border-radius: 10px; */
  z-index: 1;
}
.login__banner {
  background: url("@/assets/images/bg/auth-bg.png") no-repeat;
  background-position: center;
  background-size: cover;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>